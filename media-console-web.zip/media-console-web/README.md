# Media Console — website

Static HTML. No build step. Netlify publishes the repository root exactly as it is.

---

## Adding a page

1. Copy `_page-template.html` into the right folder as `index.html`.
   `/services/` → `services/index.html` → serves at `www.media-console.com/services/`
2. Edit the five marked lines in `<head>`: title, description, canonical, og:title, og:description.
3. Write the page content between the two `PAGE CONTENT` comments.
4. Add the URL to `sitemap.xml`.

Do not add `class="is-active"` to a nav link. `nav.js` works it out from the URL, including on detail pages — `/work/anantara/` highlights Work automatically.

---

## The one rule that keeps 30 static pages sane

The nav and footer are **byte-identical on every page**. They are wrapped in markers:

```
<!-- NAV:START --> … <!-- NAV:END -->
<!-- FOOTER:START --> … <!-- FOOTER:END -->
<!-- CTA:START --> … <!-- CTA:END -->
```

`_page-template.html` is the single source of truth for all three. When one changes:

1. Edit `_page-template.html` first.
2. Copy the block including its markers.
3. Find-and-replace across every `.html` file in the repo.

Because the blocks are identical everywhere, this is a plain mechanical replace with no per-page exceptions. The moment you hand-tweak one page's nav, that guarantee is gone and drift begins.

**Files starting with `_` are not published pages.** They are references. `_page-template.html` and `_styleguide.html` both carry `noindex`, but neither is linked from the site.

---

## Structure

```
/                       index.html (Home)
/about/                 /how-it-works/
/services/              /faqs/
/services/{slug}/       /careers/
/work/                  /careers/{slug}/
/work/{slug}/           /privacy-policy/
/case-studies/          /cookie-policy/
/case-studies/{slug}/   404.html
/contact/
```

Four service pages: `data-insights`, `strategy`, `performance-marketing`, `creative-solutions`.

Work filters are client-side state on `/work/`, not separate URLs — three near-identical pages would split ranking signal.

**Work vs Case Studies.** Work is the visual portfolio: what we made, imagery-led, kept broad. Case Studies are the evidence: problem, approach, measured result, kept few and deep. A project can appear in both, with the Work page linking through.

---

## CSS

One stylesheet: `assets/css/main.css`, layered internally in this order.

```
1 Fonts   2 Tokens   3 Reset   4 Base type
5 Layout  6 Components  7 Utilities  8 Motion
```

Never use `@import` to split it — that loads serially and delays first paint. Add to the right layer instead.

**Naming:** BEM. `.card` · `.card__title` · `.card--featured`. State is `.is-` prefixed.

**Spacing lives on single-class selectors only.** No element selectors carry margin or padding, so nothing silently cancels out.

**Never hardcode a hex value.** Every colour is a token in `:root`. If you need a colour that is not there, it belongs in the token block with a name, or it does not belong on the site.

---

## Non-negotiables

- **Tabular figures.** Every stat, table cell, and metric uses `font-variant-numeric: tabular-nums`. Proportional figures drift out of alignment in columns and make data sections look careless.
- **Stat bars encode real proportions.** The inline `width` on `.stat__bar > i` must reflect the actual value. A decorative width is a lie in a chart.
- **Charts are hand-authored inline SVG.** Give every one `role="img"` and an `aria-label` that states the finding, not the chart type.
- **Motion stays in the 0.3–0.4s band** and is defined by the `--dur` tokens. `prefers-reduced-motion` is already handled globally; do not add animation that bypasses it.
- **Focus must stay visible.** Never remove the `:focus-visible` outline.
- **Every image needs `alt`, explicit `width` and `height`, and `loading="lazy"`** below the fold.

---

## Fonts

Poppins is self-hosted, not loaded from the Google Fonts CDN — it is faster and avoids a third-party request that the Cookie Policy would otherwise have to account for.

Download 400, 500, 600, 700 weights as woff2 from `fonts.google.com/specimen/Poppins` and place them in `assets/fonts/` as:

```
poppins-400.woff2   poppins-500.woff2
poppins-600.woff2   poppins-700.woff2
```

Until they are added the site falls back to the system sans and still renders correctly.

---

## Contact form

Use Netlify Forms — add `netlify` and a honeypot to the `<form>`:

```html
<form name="contact" method="POST" data-netlify="true" netlify-honeypot="bot-field">
  <input type="hidden" name="form-name" value="contact">
  <p class="visually-hidden"><label>Leave blank: <input name="bot-field"></label></p>
  …
</form>
```

No backend, no API key, spam filtering included. Submissions appear in the Netlify dashboard.

---

## Before launch

- [ ] Poppins woff2 files added
- [ ] Real hotel photography replacing placeholders, WebP at 800px and 1600px
- [ ] Client logos in the marquee, set twice in the track so the loop is seamless
- [ ] `sitemap.xml` covers every published URL
- [ ] Canonical tag correct and unique on every page
- [ ] Contrast checked on any new colour pairing
- [ ] Keyboard-only pass: tab through every page, confirm focus is always visible
- [ ] Lighthouse on Home, Services, and a case study
