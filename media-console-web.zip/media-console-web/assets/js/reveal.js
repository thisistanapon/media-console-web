/* ==========================================================================
   reveal.js — scroll-triggered reveals and stat bar fills

   Add class="reveal" to any element. Optional .reveal--d1 / d2 / d3 stagger.
   Stat bars fill to the width set by their inline --bar custom property.

   If the visitor prefers reduced motion, everything is shown immediately
   and no observer is created.
   ========================================================================== */

(function () {
  "use strict";

  var reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  function showAll() {
    document.querySelectorAll(".reveal").forEach(function (el) {
      el.classList.add("is-visible");
    });
    document.querySelectorAll(".stat__bar > i").forEach(function (bar) {
      bar.style.width = bar.dataset.bar || "100%";
    });
  }

  function init() {
    if (reduced || !("IntersectionObserver" in window)) {
      showAll();
      return;
    }

    // Bars start at zero, then fill when scrolled into view.
    document.querySelectorAll(".stat__bar > i").forEach(function (bar) {
      bar.dataset.bar = bar.style.width || "100%";
      bar.style.width = "0%";
    });

    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;
        var el = entry.target;

        el.classList.add("is-visible");

        el.querySelectorAll(".stat__bar > i").forEach(function (bar) {
          bar.style.width = bar.dataset.bar;
        });
        if (el.matches(".stat")) {
          var own = el.querySelector(".stat__bar > i");
          if (own) own.style.width = own.dataset.bar;
        }

        observer.unobserve(el);
      });
    }, { rootMargin: "0px 0px -10% 0px", threshold: 0.15 });

    document.querySelectorAll(".reveal, .stat").forEach(function (el) {
      observer.observe(el);
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
