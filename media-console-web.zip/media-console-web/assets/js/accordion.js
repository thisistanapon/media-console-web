/* ==========================================================================
   accordion.js — FAQ and any disclosure list

   Markup contract:
   <div class="accordion" data-accordion>
     <div class="accordion__item">
       <h3><button class="accordion__trigger" aria-expanded="false"
                   aria-controls="a1">Question<span class="accordion__icon"></span></button></h3>
       <div class="accordion__panel" id="a1" role="region">
         <div class="accordion__inner"><div>Answer</div></div>
       </div>
     </div>
   </div>

   Add data-accordion="single" to close others when one opens.
   ========================================================================== */

(function () {
  "use strict";

  function init() {
    document.querySelectorAll("[data-accordion]").forEach(function (root) {
      var single = root.dataset.accordion === "single";
      var triggers = root.querySelectorAll(".accordion__trigger");

      triggers.forEach(function (trigger) {
        var panel = document.getElementById(trigger.getAttribute("aria-controls"));
        if (!panel) return;

        trigger.addEventListener("click", function () {
          var isOpen = trigger.getAttribute("aria-expanded") === "true";

          if (single && !isOpen) {
            triggers.forEach(function (other) {
              if (other === trigger) return;
              var otherPanel = document.getElementById(other.getAttribute("aria-controls"));
              other.setAttribute("aria-expanded", "false");
              if (otherPanel) otherPanel.classList.remove("is-open");
            });
          }

          trigger.setAttribute("aria-expanded", String(!isOpen));
          panel.classList.toggle("is-open", !isOpen);
        });
      });
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
