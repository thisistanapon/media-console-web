/* ==========================================================================
   nav.js — header behaviour

   The nav markup is identical on every page. Active state is derived from
   the URL here, so you never hand-edit a page to mark its own nav item.
   That is what makes find-and-replace across all pages safe.
   ========================================================================== */

(function () {
  "use strict";

  /* --- Active link ------------------------------------------------------ */

  function setActiveLink() {
    var path = window.location.pathname
      .replace(/index\.html$/, "")
      .replace(/\/+$/, "") || "/";

    var links = document.querySelectorAll(".nav__link");

    Array.prototype.forEach.call(links, function (link) {
      var href = (link.getAttribute("href") || "")
        .replace(/index\.html$/, "")
        .replace(/\/+$/, "") || "/";

      var isMatch = href === "/"
        ? path === "/"
        : path === href || path.indexOf(href + "/") === 0;

      if (isMatch) {
        link.classList.add("is-active");
        if (path === href) link.setAttribute("aria-current", "page");
      }
    });
  }

  /* --- Mobile panel ----------------------------------------------------- */

  function initToggle() {
    var toggle = document.querySelector(".nav__toggle");
    var nav = document.querySelector(".nav");
    if (!toggle || !nav) return;

    function setOpen(open) {
      toggle.setAttribute("aria-expanded", String(open));
      nav.classList.toggle("is-open", open);
      document.body.classList.toggle("is-nav-open", open);
    }

    toggle.addEventListener("click", function () {
      setOpen(toggle.getAttribute("aria-expanded") !== "true");
    });

    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && toggle.getAttribute("aria-expanded") === "true") {
        setOpen(false);
        toggle.focus();
      }
    });

    // Close when a link is tapped
    nav.addEventListener("click", function (e) {
      if (e.target.closest("a")) setOpen(false);
    });

    // Reset when resizing up to desktop
    var mq = window.matchMedia("(min-width: 901px)");
    var onChange = function (e) { if (e.matches) setOpen(false); };
    if (mq.addEventListener) mq.addEventListener("change", onChange);
    else mq.addListener(onChange);
  }

  /* --- Border on scroll -------------------------------------------------- */

  function initScrollState() {
    var header = document.querySelector(".header");
    if (!header) return;

    var ticking = false;
    function update() {
      header.classList.toggle("is-scrolled", window.scrollY > 8);
      ticking = false;
    }
    window.addEventListener("scroll", function () {
      if (!ticking) { window.requestAnimationFrame(update); ticking = true; }
    }, { passive: true });
    update();
  }

  function init() {
    setActiveLink();
    initToggle();
    initScrollState();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
